#include<bits/stdc++.h>
#define maxn 500010
using namespace std;
int fa[maxn],nxt[maxn],first[maxn],to[maxn],st[maxn],top,n,dad,num;
char s[maxn];
long long w[maxn],sum[maxn],ans;
void add(int a,int b){
	to[++num]=b;
	nxt[num]=first[a];
	first[a]=num;
}
void dfs(int k){
	int tmp=0;
	if(s[k]=='(')
	{
		st[++top]=k;
		w[k]=0;//��ʡ 
	}
	else if(top){
		tmp=st[top--];
		w[k]=w[fa[tmp]]+1;
	} else {
		w[k]=0;//��ʡ 
	}
	sum[k]=sum[fa[k]]+w[k];
	for(int i=first[k];i;i=nxt[i])
	dfs(to[i]);
	if(s[k]=='(') --top;
	else if(tmp) st[++top]=tmp;
}
int main(){
	scanf("%d",&n);
	getchar();
	scanf("%s",s+1);
	for(int i=1;i<n;i++){
		scanf("%d",&dad);
		fa[i+1]=dad;
		add(dad,i+1);
	}
	dfs(1);
	for(int i=1;i<=n;i++)
	ans=ans^(i*sum[i]);
	printf("%lld",ans);
	return 0;
}

