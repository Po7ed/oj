#include<bits/stdc++.h>
#define maxm 100010
#define mod 10007
using namespace std;
int m,n,ans;
int number[maxm],color[maxm],cnt[maxm][3],isum[maxm][3],nsum[maxm][3],psum[maxm][3];
int main()
{
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d",&number[i]);
	for(int i=1;i<=n;i++) scanf("%d",&color[i]);
	for(int i=1;i<=n;i++)
	{
		int col=color[i];
		int type=i%2;
		number[i]=number[i]%mod;
		ans=(ans+psum[col][type]+isum[col][type]*number[i]+i*nsum[col][type]+(i*number[i]%mod)*cnt[col][type])%mod;
		cnt[col][type]=(cnt[col][type]+1)%mod;
		isum[col][type]=(isum[col][type]+i)%mod;
		nsum[col][type]=(nsum[col][type]+number[i])%mod;
		psum[col][type]=(psum[col][type]+i*number[i])%mod;
	}
	printf("%d\n",ans);
	return 0;
}
