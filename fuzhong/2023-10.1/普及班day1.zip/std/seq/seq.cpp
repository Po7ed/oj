#include<bits/stdc++.h>
#define maxn 100010
#define mod 10007
using namespace std;
int a[maxn],t[maxn],pos[maxn],cnt[maxn],p[maxn];
int n,ans1,ans2;
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++) {
		scanf("%d",&a[i]);
		t[i]=a[i];
	}
	p[0]=1;
	for(int i=1;i<=n;i++) p[i]=p[i-1]*2 % mod;
	sort(t+1,t+n+1);
	int tmp=unique(t+1,t+n+1)-t-1;
	for(int i=1;i<=n;i++) {
		a[i]=lower_bound(t+1,t+tmp+1,a[i])-t;
		ans1=(ans1+p[n-1-cnt[a[i]]])%mod;
		cnt[a[i]]++;
		ans2=(ans2+1ll*(i-pos[a[i]])*(n-i+1)%mod) % mod;
		pos[a[i]]=i;
	}
	printf("%d %d",ans1,ans2);
	return 0;
}
