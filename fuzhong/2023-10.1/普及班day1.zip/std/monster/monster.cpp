#include<bits/stdc++.h>
#define maxn 510
using namespace std;
int a,b,p,q,s,k,head,tail,nowx,nowy,xx,yy,qq[maxn*maxn][2],step[maxn][maxn];
int main(){
    cin>>a>>b>>p>>q>>s>>k;
    memset(step,-1,sizeof(step));
    //��� 
    step[a][b]=0;
    qq[tail][0]=a;
    qq[tail++][1]=b;
    if(b==0 && a==k){
        printf("0");
        return 0;
    }
    while(head<tail){
        nowx=qq[head][0];
        nowy=qq[head++][1];
        //����
        xx=nowx;
        yy= nowy-p;
        if(yy<=0){//�����̬ 
            if(xx==k) return !printf("%d",step[nowx][nowy]+1);
        }else{
           xx-=p;
           yy+=q;
           if(yy>b) yy=b;
           if(xx>0){
            if(step[xx][yy]==-1){//�Ϸ�״̬��δ���ʹ� 
                qq[tail][0]=xx;
                qq[tail++][1]=yy;
                step[xx][yy]=step[nowx][nowy]+1;
            }
           } 
        }
        //����
        xx=nowx+s;
        if(xx>a) xx=a;
        xx-=p;
        yy=nowy+q;
        if(yy>b) yy=b;
        //�����ܵ���Ŀ��״̬ 
        if(xx>0){
            if(step[xx][yy]==-1){//�Ϸ�״̬��δ���ʹ� 
                qq[tail][0]=xx;
                qq[tail++][1]=yy;
                step[xx][yy]=step[nowx][nowy]+1;
            }
        }   
    }
    printf("-1");
    return 0;
}
