#include<bits/stdc++.h>
#define maxn 5010
using namespace std;
int a[maxn],n,k;
int main(){
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;++i) scanf("%d",&a[i]);
	sort(a+1,a+k+1);
	for(int i=1;i<=k;++i) {
		printf("%d",a[i]);
		if(i!=k) printf(" ");
	}
	return 0;
}
