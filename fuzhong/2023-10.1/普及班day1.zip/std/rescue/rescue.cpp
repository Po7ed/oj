#include<bits/stdc++.h>
#define maxn 100010
#define LL long long
using namespace std;
LL l,r,mid;
int n,k,t,x,y,num;
LL f[maxn],g[maxn];
int w[maxn],first[maxn],nxt[maxn*2],to[maxn*2];
bool p[maxn];
void add(int x,int y){
	to[++num]=y;
	nxt[num]=first[x];
	first[x]=num;
}
void dfs(int now,int fa){
	LL v=0,c;
	if(p[now]) v=mid;
	c=w[now];
	for(int i=first[now];i;i=nxt[i]){
		int tmp=to[i];
		if(tmp==fa) continue;
		dfs(tmp,now);
		v=max(v,f[tmp]);
		c+=g[tmp];
	}
	if(v>=c){
		g[now]=0;
		f[now]=v-c;
	}else{
		f[now]=0;
		g[now]=c;
	}
}
bool check(){
	memset(f,0,sizeof(f));
	memset(g,0,sizeof(g));
	dfs(1,0);
	if(g[1]>0) return false;
	else return true;
}
int main(){
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) {
		scanf("%d",&w[i]);
		r+=w[i];
	}
	for(int i=1;i<=k;i++){
		scanf("%d",&t);
		p[t]=true;
	}
	for(int i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	while(r-l>1){
		mid=r+l>>1;
		if(check()) r=mid;
		else l=mid;
	}
	printf("%lld",r);
	return 0;
}
