#include<bits/stdc++.h>
using namespace std;
using ll = long long;
const int MN = 1e5 + 5;
vector<int> go[MN];
int n, a[MN], b[MN], id[MN], m;
void solve() {
    cin >> n >> m;
    for(int i = 1; i <= n; i++) {
        cin >> a[i] >> b[i];
        go[a[i]].push_back(i);
    }
    for(int i = 1; i <= m; i++) {
        int now = go[i][0];
        for(int x : go[i])
            if(b[x] > b[now]) now = x;
        cout << now << " \n"[i == m];
    }
}
int main() {
    freopen("election.in", "r", stdin);
    freopen("election.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int TT = 1;
    // cin >> TT;
    while(TT--) {
        solve();
    }
}