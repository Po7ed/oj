#include<bits/stdc++.h>
using namespace std;
const int MN = 5e6 + 5;
using ll = long long;
const int Mod = 998244353;
namespace IO {
    const int lim = 1 << 20;
    char buffer[lim], *S, *T;
    char gc() {
        if(S == T) {
            T = (S = buffer) + fread(buffer, 1, lim, stdin);
            if(S == T) return EOF;
        }
        return *S++;
    }
    template<typename T>
    void read(T& x) {
        char c;
        while((c = gc()) < '0' || c > '9');
        for(x = (c ^ '0'); (c = gc()) >= '0' && c <= '9';)
            x = (x << 3) + (x << 1) + (c ^ '0');
        
    }
}
int n;
ll a[MN], sum[MN];
void add(int& x, int y) {
    (x += y) >= Mod ? x -= Mod : 0;
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
    cin >> n;
    for(int i = 1; i <= n; i++) {
        cin >> a[i];
        sum[i] = sum[i - 1];
        sum[i] += a[i];
    }
    if(sum[n] & 1) {
        cout << "0\n";
        return 0;
    }
    int k = 0, ans = 1;
    for(int i = 1, j = 1; i <= n; i++) {
        for(; j <= n && sum[i] + sum[n] / 2 > sum[j]; j++);
        if(j <= n && sum[i] + sum[n] / 2 == sum[j]) {
            k++;
        }
    }
    int nk = k;
    while(k--) add(ans, ans);
    ans = (ans - nk - 1 + Mod) % Mod;
    cout << ans << "\n";
}