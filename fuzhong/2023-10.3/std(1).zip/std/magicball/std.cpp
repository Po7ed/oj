#include <bits/stdc++.h>
using namespace std;
 
using ll = long long;
using ld = long double;
using ull = unsigned long long;
 
const int N = 50 + 5;
 
ll f[N], g[N];
 
ll solve(int n, ll k) {
    if (n == 0) return 1;
    if (n == 1) return 3;
    if (k <= g[n - 2]) return solve(n - 2, k);
    if (k <= 2 * g[n - 2]) return f[n - 2] + solve(n - 2, k - g[n - 2]);
    return 2 * f[n - 2] + solve(n - 1, k - 2 * g[n - 2]);
}
 
int main() {
    freopen("magicball.in", "r", stdin);
    freopen("magicball.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
    int n;
    ll k;
    cin >> n >> k;
    f[0] = 1; f[1] = 3; g[0] = 1; g[1] = 1;
    for (int i = 2; i <= n; i++) {
        f[i] = 2 * f[i - 2] + f[i - 1];
        g[i] = 2 * g[i - 2] + g[i - 1];
    }
    cout << solve(n, k) << "\n";
    return 0;
}