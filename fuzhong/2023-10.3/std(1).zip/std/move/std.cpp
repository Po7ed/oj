#include<bits/stdc++.h>
using namespace std;
using ll = long long;
const int MN = 2e5 + 5;
const ll inf = 1e18;
using P = pair<int, int>;
map<P, bool> mp;
int n, ans;
bool dis[105][105], vis[105][105];
P que[MN];
int qn;
string str;
const int gx[] = {-1, 1, 0, 0};
const int gy[] = {0, 0, -1, 1};
int ha[405];
void solve() {
    ha['L'] = 0; ha['R'] = 1;
    ha['D'] = 2; ha['U'] = 3;
    cin >> n >> str;
    int N = (1 << n);
    for(int i = 0; i < N; i++) {
        int x = 50, y = 50;
        que[qn = 1] = P(x, y);
        vis[x][y] = 1;
        dis[x][y] = 0;
        bool ok = 1;
        for(int j = 0; j < n; j++) {
            int c = ha[str[j]];
            int nx = x + gx[c], ny = y + gy[c];
            if((i >> j) & 1) {
                if(vis[nx][ny] && dis[nx][ny]) {
                    ok = 0;
                    break;
                }
                vis[nx][ny] = 1;
                dis[nx][ny] = 0;
                x = nx; y = ny;
            } else {
                if(vis[nx][ny] && !dis[nx][ny]) {
                    ok = 0;
                    break;
                }
                vis[nx][ny] = 1;
                dis[nx][ny] = 1;
            }
            que[++qn] = P(nx, ny);
        }
        if(ok && mp.find(P(x, y)) == mp.end()) {
            mp[P(x, y)] = 1;
        }
        for(int j = 1; j <= qn; j++) {
            int xx = que[j].first, yy = que[j].second;
            vis[xx][yy] = 0;
            dis[xx][yy] = 0;
        }
    }
    cout << mp.size() << "\n";
    for(auto [x, y] : mp) cout << x.first - 50 << " " << x.second - 50 << "\n";
}
int main() {
    freopen("move.in", "r", stdin);
    freopen("move.out", "w", stdout);
    cin.tie(nullptr); cout.tie(nullptr);
    ios::sync_with_stdio(false);
    int TT = 1;
    // cin >> TT;
    while(TT--) {
        solve();
    }
}