#include <bits/stdc++.h>
using namespace std;

#define fec(i, x, y) (int i = head[x], y = g[i].to; i; i = g[i].ne, y = g[i].to)
#define dbg(...) fprintf(stderr, __VA_ARGS__)
#define fi first
#define se second

using ll = long long; using ull = unsigned long long; using pii = pair<int, int>;

template <typename A, typename B> bool smax(A &a, const B &b) { return a < b ? a = b, 1 : 0; }
template <typename A, typename B> bool smin(A &a, const B &b) { return b < a ? a = b, 1 : 0; }

namespace io {
	const int SIZE = (1 << 15) + 1;
	char ibuf[SIZE], *iS, *iT, obuf[SIZE], *oS = obuf, *oT = obuf + SIZE - 1, c, qu[55];
	int f, qr;
    #define gc() (iS == iT ? (iT = (iS = ibuf) + fread(ibuf, 1, SIZE, stdin), iS == iT ? EOF : *(iS++)) : *(iS++))

	void flush() { fwrite(obuf, 1, oS - obuf, stdout), oS = obuf; }
	void putc(char c) { *(oS++) = c; if (oS == oT) flush(); }
	template <typename I> void read(I& x) {
		for (f = 1, c = gc(); c < '0' || c > '9'; c = gc()) c == '-' ? f = -1 : 0;
		for (x = 0; c >= '0' && c <= '9'; c = gc()) x = (x << 1) + (x << 3) + (c & 15);
		~f ? 0 : x = -x;
	}
	template <typename I> void write(I x) {
		if (x == 0) putc('0');
		if (x < 0) x = -x, putc('-');
		for (; x; x /= 10) qu[++qr] = x % 10 + '0';
		for (; qr;) putc(qu[qr--]);
	}
	struct Flusher_ { ~Flusher_() { flush(); } } io_flusher;
}
using namespace io;

constexpr int N = 1e7 + 7;
constexpr int P = 998244353;

int n;
ll a[N];

int smod(int x) { return x >= P ? x - P : x; }
void sadd(int &x, const int &y) { x += y; x >= P ? x -= P : x; }
int fpow(int x, int y) {
    int ans = 1;
    for (; y; y >>= 1, x = (ll)x * x % P) if (y & 1) ans = (ll)ans * x % P;
    return ans;
}

int main() {
    // freopen("circle.in", "r", stdin);
    // freopen("circle.out", "w", stdout);
    
    ios::sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    
    read(n);
    for (int i = 1; i <= n; ++i) read(a[i]), a[i] += a[i - 1];
    ll m = a[n];
    if (m & 1) {
        cout << "0\n";
        return 0;
    }
    ll m2 = m / 2;
    int cnt = 0;
    for (int i = 0, j = 0; i <= n; ++i) if (a[i] < m2) {
        while (j < n && a[j] < a[i] + m2) ++j;
        if (j >= n) break;
        if (a[j] == a[i] + m2) ++cnt;
    }
    int ans = fpow(2, cnt);
    ans = smod(ans + P - cnt - 1);
    cout << ans << '\n';
    
    return 0;
}